<?php $__env->startSection('title', 'Messages'); ?>
<?php $__env->startSection('kicker', 'Inbox'); ?>
<?php $__env->startSection('heading', 'Messages'); ?>

<?php $__env->startSection('content'); ?>
<div class="page-title-row">
    <div>
        <h2>Enquiries</h2>
        <p>Messages sent through the contact and tuition enquiry forms.</p>
    </div>
    <?php if($unreadCount > 0): ?>
        <span class="badge badge--new"><?php echo e($unreadCount); ?> unread</span>
    <?php endif; ?>
</div>

<div class="toolbar">
    <form method="GET" action="<?php echo e(route('admin.messages.index')); ?>" class="search-form" style="flex-wrap:wrap;">
        <input type="text" name="q" value="<?php echo e($search); ?>" placeholder="Search name, email or subject…" aria-label="Search messages">

        <select name="status" class="select-input" aria-label="Filter by status">
            <option value="">All statuses</option>
            <option value="new" <?php echo e($status === 'new' ? 'selected' : ''); ?>>New</option>
            <option value="read" <?php echo e($status === 'read' ? 'selected' : ''); ?>>Read</option>
            <option value="archived" <?php echo e($status === 'archived' ? 'selected' : ''); ?>>Archived</option>
        </select>

        <select name="source" class="select-input" aria-label="Filter by source">
            <option value="">All sources</option>
            <option value="contact" <?php echo e($source === 'contact' ? 'selected' : ''); ?>>Contact form</option>
            <option value="tuition" <?php echo e($source === 'tuition' ? 'selected' : ''); ?>>Tuition enquiry</option>
        </select>

        <button type="submit" class="btn-admin btn-admin--ghost btn-admin--sm">Filter</button>

        <?php if($search !== '' || $status !== '' || $source !== ''): ?>
            <a href="<?php echo e(route('admin.messages.index')); ?>" class="text-link-admin" style="font-size:0.75rem;">Reset</a>
        <?php endif; ?>
    </form>
</div>

<section class="panel">
    <div class="table-wrap">
        <table class="data-table">
            <thead>
                <tr>
                    <th>From</th>
                    <th>Subject</th>
                    <th>Source</th>
                    <th>Received</th>
                    <th>Status</th>
                    <th style="text-align:right;">Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td>
                            <div class="cell-title">
                                <span>
                                    <strong><?php echo e($message->full_name); ?></strong>
                                    <span><?php echo e($message->email); ?></span>
                                </span>
                            </div>
                        </td>
                        <td><?php echo e(\Illuminate\Support\Str::limit($message->subject ?: 'General enquiry', 46)); ?></td>
                        <td><span class="badge badge--<?php echo e($message->source); ?>"><?php echo e($message->source); ?></span></td>
                        <td><?php echo e($message->created_at->format('j M Y, H:i')); ?></td>
                        <td><span class="badge badge--<?php echo e($message->status); ?>"><?php echo e($message->status); ?></span></td>
                        <td>
                            <div class="row-actions" style="justify-content:flex-end;">
                                <a href="<?php echo e(route('admin.messages.show', $message)); ?>" class="btn-admin btn-admin--ghost btn-admin--sm">Open</a>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="6">
                            <div class="empty-row">
                                <strong>No messages found</strong>
                                <?php echo e($search !== '' || $status !== '' || $source !== '' ? 'Try changing or resetting the filters.' : 'New enquiries from the website will appear here.'); ?>

                            </div>
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <?php if($messages->hasPages()): ?>
        <div class="pagination-wrap">
            <?php echo e($messages->onEachSide(1)->links('vendor.pagination.admin')); ?>

        </div>
    <?php endif; ?>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Graysexamcentre\resources\views\admin\messages\index.blade.php ENDPATH**/ ?>