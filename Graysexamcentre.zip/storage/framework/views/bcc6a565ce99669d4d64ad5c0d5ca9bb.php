<?php $__env->startSection('title', $content['title']); ?>
<?php $__env->startSection('meta_description', $content['meta']); ?>

<?php $__env->startSection('content'); ?>
<section class="blog-hero">
    <div class="page-hero-glow" aria-hidden="true"></div>
    <div class="container blog-hero-inner reveal">
        <nav class="breadcrumb" aria-label="Breadcrumb">
            <a href="<?php echo e(route('home')); ?>">Home</a>
            <span aria-hidden="true">/</span>
            <span>Sitemap</span>
        </nav>
        <p class="eyebrow"><span class="eyebrow-dot"></span><span data-edit-key="eyebrow"><?php echo e($content['eyebrow']); ?></span></p>
        <h1 data-edit-key="hero_title"><?php echo e($content['hero_title']); ?></h1>
        <p class="lead" data-edit-key="hero_text" data-edit-type="textarea"><?php echo e($content['hero_text']); ?></p>
    </div>
</section>

<section class="section section--paper">
    <div class="container">
        <div class="sitemap-grid">
            <?php $__currentLoopData = $groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $groupName => $links): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <article class="sitemap-card reveal">
                    <h2><?php echo e($groupName); ?></h2>
                    <ul>
                        <?php $__currentLoopData = $links; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $routeName => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><a href="<?php echo e(route($routeName)); ?>"><?php echo e($label); ?></a></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </article>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</section>

<section class="section section--cream">
    <div class="container">
        <div class="section-head section-head--split reveal">
            <div>
                <p class="eyebrow"><span class="eyebrow-dot"></span><span data-edit-key="posts_eyebrow"><?php echo e($content['posts_eyebrow']); ?></span></p>
                <h2 data-edit-key="posts_title"><?php echo e($content['posts_title']); ?></h2>
            </div>
            <div>
                <a href="<?php echo e(route('blog')); ?>" class="text-link"><span data-edit-key="posts_link_label"><?php echo e($content['posts_link_label']); ?></span>
                    <svg viewBox="0 0 20 20" fill="none" aria-hidden="true"><path d="M4 10h11m0 0-4.2-4.2M15 10l-4.2 4.2" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"/></svg>
                </a>
            </div>
        </div>

        <ul class="sitemap-post-list reveal">
            <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li>
                    <a href="<?php echo e(route('blog.post', $post['slug'])); ?>"><?php echo e($post['title']); ?></a>
                    <span><?php echo e(\Illuminate\Support\Carbon::parse($post['date'])->format('j M Y')); ?></span>
                </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Graysexamcentre\resources\views\pages\sitemap.blade.php ENDPATH**/ ?>