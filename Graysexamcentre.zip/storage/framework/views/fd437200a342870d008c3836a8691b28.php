<?php $__env->startSection('title', 'Edit course'); ?>
<?php $__env->startSection('kicker', 'Tuition'); ?>
<?php $__env->startSection('heading', 'Edit course'); ?>

<?php $__env->startSection('content'); ?>
<div class="page-title-row">
    <div>
        <h2><?php echo e($course->title); ?></h2>
        <p>Update the course details shown on the public website.</p>
    </div>
    <div style="display:flex;gap:0.5rem;flex-wrap:wrap;">
        <a href="<?php echo e(route('tuition.centre', ['course' => $course->title])); ?>#enquire" target="_blank" rel="noopener" class="btn-admin btn-admin--ghost">View on site</a>
        <a href="<?php echo e(route('admin.courses.index')); ?>" class="btn-admin btn-admin--ghost">&larr; Back to courses</a>
    </div>
</div>

<?php echo $__env->make('admin.courses._form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Graysexamcentre\resources\views\admin\courses\edit.blade.php ENDPATH**/ ?>