<?php
    $contact = \App\Support\SiteContent::get('contact');
?>

<footer class="site-footer">
    <div class="footer-glow" aria-hidden="true"></div>
    <div class="container">
        <div class="footer-grid">
            <div class="footer-brand">
                <a href="<?php echo e(route('home')); ?>" class="brand brand--footer" aria-label="Grays Exam Centre home">
                    <span class="brand-mark" aria-hidden="true">
                        <svg viewBox="0 0 64 64" fill="none"><rect width="64" height="64" rx="17" fill="#f5efe6"/><path d="M32 11.5 46.5 19v13.2c0 10.4-6.3 17.7-14.5 20.6-8.2-2.9-14.5-10.2-14.5-20.6V19L32 11.5Z" stroke="#b65c3d" stroke-width="2.1"/><path d="M38.8 25.4a8.1 8.1 0 1 0 0 13.2" stroke="#23283d" stroke-width="3.1" stroke-linecap="round"/><circle cx="41.4" cy="32" r="2" fill="#b65c3d"/></svg>
                    </span>
                    <span class="brand-text">
                        <span class="brand-name">Grays</span>
                        <span class="brand-sub">Exam Centre</span>
                    </span>
                </a>
                <p>Confidence, built in. A modern private exam centre and tuition centre serving Grays and North Essex.</p>
                <div class="footer-badges">
                    <span>JCQ compliant</span>
                    <span>Private candidates</span>
                </div>
            </div>

            <div class="footer-col">
                <h3>Explore</h3>
                <a href="<?php echo e(route('exams')); ?>">Exams</a>
                <a href="<?php echo e(route('exam.registration')); ?>">Exam registration</a>
                <a href="<?php echo e(route('tuition.centre')); ?>">Tuition Centre</a>
                <a href="<?php echo e(route('tuition')); ?>">Tuition</a>
                <a href="<?php echo e(route('form')); ?>">Online form</a>
                <a href="<?php echo e(route('practical.endorsement')); ?>">Practical endorsement</a>
                <a href="<?php echo e(route('online.learning')); ?>">Online learning</a>
                <a href="<?php echo e(route('blog')); ?>">Blog</a>
                <a href="<?php echo e(route('contact.us')); ?>">Contact Us</a>
                <a href="<?php echo e(route('sitemap')); ?>">Sitemap</a>
            </div>

            <div class="footer-col">
                <h3>Opening hours</h3>
                <p><?php echo e($contact['hours_weekday']); ?></p>
                <p><?php echo e($contact['hours_saturday']); ?></p>
                <p><?php echo e($contact['hours_sunday']); ?></p>
            </div>

            <div class="footer-col">
                <h3>Visit us</h3>
                <p><?php echo e($contact['address_line1']); ?><br><?php echo e($contact['address_line2']); ?><br><?php echo e($contact['city']); ?> <?php echo e($contact['postcode']); ?></p>
                <a href="tel:<?php echo e(preg_replace('/\s+/', '', $contact['phone'])); ?>"><?php echo e($contact['phone']); ?></a>
                <a href="mailto:<?php echo e($contact['email']); ?>"><?php echo e($contact['email']); ?></a>
            </div>
        </div>

        <div class="footer-bottom">
            <span>&copy; <?php echo e(date('Y')); ?> Grays Exam Centre. All rights reserved.</span>
            <span class="footer-legal">
                <a href="<?php echo e(route('privacy.policy')); ?>">Privacy</a>
                <a href="<?php echo e(route('cookie.policy')); ?>">Cookies</a>
                <a href="<?php echo e(route('terms.of.use')); ?>">Terms</a>
                <a href="<?php echo e(route('login')); ?>">Staff login</a>
            </span>
            <span>Grays, Essex · United Kingdom</span>
        </div>
    </div>
</footer>
<?php /**PATH C:\xampp\htdocs\Graysexamcentre\resources\views/partials/footer.blade.php ENDPATH**/ ?>