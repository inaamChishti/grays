<?php $__env->startSection('title', 'Website pages'); ?>
<?php $__env->startSection('kicker', 'Website'); ?>
<?php $__env->startSection('heading', 'Website pages'); ?>

<?php $__env->startSection('content'); ?>
<div class="page-title-row">
    <div>
        <h2>All editable pages</h2>
        <p>Choose any page to edit its text and images in the same visual editor used for the home page.</p>
    </div>
    <a href="<?php echo e(route('home')); ?>" target="_blank" rel="noopener" class="btn-admin btn-admin--ghost">View website</a>
</div>

<?php $__currentLoopData = $groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $groupName => $pages): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <section class="panel page-admin-panel">
        <div class="panel-head">
            <h2><?php echo e($groupName); ?></h2>
            <span class="page-admin-count"><?php echo e(count($pages)); ?> <?php echo e(\Illuminate\Support\Str::plural('page', count($pages))); ?></span>
        </div>
        <div class="panel-body">
            <div class="page-admin-grid">
                <?php $__currentLoopData = $pages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slug => $name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="<?php echo e(route('admin.pages.edit', $slug)); ?>" class="page-admin-card">
                        <span class="page-admin-icon">
                            <svg viewBox="0 0 24 24" fill="none" aria-hidden="true"><rect x="4" y="3.5" width="16" height="17" rx="2.2" stroke="currentColor" stroke-width="1.6"/><path d="M8 8h8M8 12h8M8 16h5" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/></svg>
                        </span>
                        <span class="page-admin-copy">
                            <strong><?php echo e($name); ?></strong>
                            <span>Edit text, images and settings</span>
                        </span>
                        <svg class="page-admin-arrow" viewBox="0 0 20 20" fill="none" aria-hidden="true"><path d="M4 10h11m0 0-4.2-4.2M15 10l-4.2 4.2" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"/></svg>
                    </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </section>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Graysexamcentre\resources\views\admin\pages\index.blade.php ENDPATH**/ ?>