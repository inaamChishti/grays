<?php $__env->startSection('title', $content['title']); ?>
<?php $__env->startSection('meta_description', $content['meta']); ?>

<?php $__env->startSection('content'); ?>
<?php
    $isPolicy = in_array($slug, ['privacy-policy', 'terms-of-use', 'cookie-policy'], true);
    $tones = ['paper', 'cream'];
    $blockIndex = 0;
?>

<section class="page-hero content-hero">
    <div class="page-hero-glow" aria-hidden="true"></div>
    <div class="container page-hero-grid">
        <div class="page-hero-copy reveal">
            <nav class="breadcrumb" aria-label="Breadcrumb">
                <a href="<?php echo e(route('home')); ?>">Home</a>
                <span aria-hidden="true">/</span>
                <span data-edit-key="name"><?php echo e($content['name']); ?></span>
            </nav>
            <p class="eyebrow"><span class="eyebrow-dot"></span><span data-edit-key="eyebrow"><?php echo e($content['eyebrow']); ?></span></p>
            <h1 data-edit-key="hero_title"><?php echo e($content['hero_title']); ?></h1>
            <p class="lead" data-edit-key="hero_text" data-edit-type="textarea"><?php echo e($content['hero_text']); ?></p>

            <?php if(! empty($content['hero_points'])): ?>
                <ul class="content-hero-points">
                    <?php $__currentLoopData = $content['hero_points']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pointIndex => $point): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li>
                            <svg viewBox="0 0 20 20" fill="none" aria-hidden="true"><path d="m4.5 10.5 3.4 3.4 7.6-7.8" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"/></svg>
                            <span data-edit-key="hero_points.<?php echo e($pointIndex); ?>"><?php echo e($point); ?></span>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            <?php endif; ?>

            <div class="hero-actions">
                <a href="<?php echo e(route('contact.us')); ?>" class="btn btn--primary">
                    Ask us a question
                    <svg viewBox="0 0 20 20" fill="none" aria-hidden="true"><path d="M4 10h11m0 0-4.2-4.2M15 10l-4.2 4.2" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"/></svg>
                </a>
                <?php if (! ($isPolicy)): ?>
                    <a href="<?php echo e(route('exam.registration')); ?>" class="btn btn--ghost">Start an exam entry</a>
                <?php endif; ?>
            </div>
        </div>

        <div class="page-hero-media reveal">
            <img src="<?php echo e(asset($content['hero_image'])); ?>" alt="<?php echo e($content['name']); ?> at Grays Exam Centre" data-edit-image="hero_image">
            <div class="page-hero-chip">
                <svg viewBox="0 0 20 20" fill="none" aria-hidden="true"><path d="M10 2.8 16 5.4v4.8c0 3.8-2.4 6.5-6 7.5-3.6-1-6-3.7-6-7.5V5.4L10 2.8Z" stroke="currentColor" stroke-width="1.5"/><path d="m7.4 9.8 1.8 1.8 3.5-3.6" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"/></svg>
                JCQ-compliant centre
            </div>
        </div>
    </div>
</section>

<?php $__currentLoopData = $content['blocks']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $block): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php echo $__env->make('partials.content-block', [
        'block' => $block,
        'tone' => $tones[$blockIndex % 2],
        'prefix' => 'blocks.'.$blockIndex,
    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php $blockIndex++; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php if(! empty($content['faq'])): ?>
    <?php echo $__env->make('partials.content-block', [
        'block' => array_merge(['type' => 'faq'], $content['faq']),
        'tone' => $tones[$blockIndex % 2],
        'prefix' => 'faq',
    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php endif; ?>

<?php if(! empty($content['cta'])): ?>
    <section class="cta-section content-cta">
        <div class="container">
            <div class="cta-band reveal">
                <div class="cta-orbs" aria-hidden="true"></div>
                <div class="cta-copy">
                    <p class="eyebrow eyebrow--light"><span class="eyebrow-dot"></span>Next step</p>
                    <h2 data-edit-key="cta.title"><?php echo e($content['cta']['title']); ?></h2>
                    <p data-edit-key="cta.text" data-edit-type="textarea"><?php echo e($content['cta']['text']); ?></p>
                </div>
                <div class="cta-actions">
                    <a href="<?php echo e(route($content['cta']['route'])); ?>" class="btn btn--gold">
                        <span data-edit-key="cta.label"><?php echo e($content['cta']['label']); ?></span>
                        <svg viewBox="0 0 20 20" fill="none" aria-hidden="true"><path d="M4 10h11m0 0-4.2-4.2M15 10l-4.2 4.2" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"/></svg>
                    </a>
                </div>
            </div>
        </div>
    </section>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Graysexamcentre\resources\views/pages/content.blade.php ENDPATH**/ ?>