<?php $__env->startSection('title', 'Courses'); ?>
<?php $__env->startSection('kicker', 'Tuition'); ?>
<?php $__env->startSection('heading', 'Courses'); ?>

<?php $__env->startSection('content'); ?>
<div class="page-title-row">
    <div>
        <h2>Tuition courses</h2>
        <p>Create, edit and publish the courses shown on the Tuition Centre page.</p>
    </div>
    <a href="<?php echo e(route('admin.courses.create')); ?>" class="btn-admin btn-admin--primary">
        <svg viewBox="0 0 20 20" fill="none" aria-hidden="true"><path d="M10 4v12M4 10h12" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/></svg>
        Add course
    </a>
</div>

<div class="toolbar">
    <form method="GET" action="<?php echo e(route('admin.courses.index')); ?>" class="search-form">
        <input type="text" name="q" value="<?php echo e($search); ?>" placeholder="Search by title or level…" aria-label="Search courses">
        <button type="submit" class="btn-admin btn-admin--ghost btn-admin--sm">Search</button>
        <?php if($search !== ''): ?>
            <a href="<?php echo e(route('admin.courses.index')); ?>" class="text-link-admin" style="font-size:0.75rem;">Clear</a>
        <?php endif; ?>
    </form>
</div>

<section class="panel">
    <div class="table-wrap">
        <table class="data-table">
            <thead>
                <tr>
                    <th>Course</th>
                    <th>Level</th>
                    <th>Duration</th>
                    <th>Fee</th>
                    <th>Order</th>
                    <th>Status</th>
                    <th style="text-align:right;">Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td>
                            <div class="cell-title">
                                <img class="cell-thumb" src="<?php echo e(asset($course->image ?: 'images/study-1.jpg')); ?>" alt="">
                                <span>
                                    <strong><?php echo e($course->title); ?></strong>
                                    <span><?php echo e($course->slug); ?></span>
                                </span>
                            </div>
                        </td>
                        <td><?php echo e($course->level); ?></td>
                        <td><?php echo e($course->duration ?: '—'); ?></td>
                        <td><?php echo e($course->fee ?: 'On request'); ?></td>
                        <td><?php echo e($course->sort_order); ?></td>
                        <td>
                            <span class="badge badge--<?php echo e($course->is_active ? 'active' : 'inactive'); ?>">
                                <?php echo e($course->is_active ? 'Live' : 'Hidden'); ?>

                            </span>
                        </td>
                        <td>
                            <div class="row-actions" style="justify-content:flex-end;">
                                <a href="<?php echo e(route('admin.courses.edit', $course)); ?>" class="icon-btn" title="Edit course" aria-label="Edit <?php echo e($course->title); ?>">
                                    <svg viewBox="0 0 20 20" fill="none" aria-hidden="true"><path d="M13.4 3.6a1.8 1.8 0 0 1 2.5 2.5l-8 8L5 15l.9-2.9 7.5-8.5Z" stroke="currentColor" stroke-width="1.4" stroke-linejoin="round"/></svg>
                                </a>
                                <form method="POST" action="<?php echo e(route('admin.courses.destroy', $course)); ?>" data-confirm="Delete &quot;<?php echo e($course->title); ?>&quot;? This cannot be undone.">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="icon-btn icon-btn--danger" title="Delete course" aria-label="Delete <?php echo e($course->title); ?>">
                                        <svg viewBox="0 0 20 20" fill="none" aria-hidden="true"><path d="M4 6h12M8 3.5h4M6 6l.7 10a1.5 1.5 0 0 0 1.5 1.4h3.6A1.5 1.5 0 0 0 13.3 16L14 6" stroke="currentColor" stroke-width="1.4" stroke-linecap="round"/></svg>
                                    </button>
                                </form>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="7">
                            <div class="empty-row">
                                <strong>No courses found</strong>
                                <?php echo e($search !== '' ? 'Try a different search term.' : 'Add your first tuition course to get started.'); ?>

                            </div>
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <?php if($courses->hasPages()): ?>
        <div class="pagination-wrap">
            <?php echo e($courses->onEachSide(1)->links('vendor.pagination.admin')); ?>

        </div>
    <?php endif; ?>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Graysexamcentre\resources\views\admin\courses\index.blade.php ENDPATH**/ ?>