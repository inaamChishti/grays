<?php
    $boards = \App\Support\SiteContent::get('exam-boards-section');
    $isBoardsEditor = request()->boolean('editor_preview')
        && request('editor_section') === 'exam-boards-section';
?>

<section class="boards" aria-label="Accepted exam boards">
    <div class="container boards-inner">
        <div class="boards-heading reveal">
            <div>
                <p class="eyebrow"><span class="eyebrow-dot"></span><span <?php if($isBoardsEditor): ?> data-edit-key="eyebrow" <?php endif; ?>><?php echo e($boards['eyebrow']); ?></span></p>
                <h2 <?php if($isBoardsEditor): ?> data-edit-key="heading" <?php endif; ?>><?php echo e($boards['heading']); ?></h2>
            </div>
            <div class="boards-copy">
                <p <?php if($isBoardsEditor): ?> data-edit-key="text" data-edit-type="textarea" <?php endif; ?>><?php echo e($boards['text']); ?></p>
                <a href="<?php echo e(route('contact.us')); ?>" class="text-link"><span <?php if($isBoardsEditor): ?> data-edit-key="cta_label" <?php endif; ?>><?php echo e($boards['cta_label']); ?></span>
                    <svg viewBox="0 0 20 20" fill="none" aria-hidden="true"><path d="M4 10h11m0 0-4.2-4.2M15 10l-4.2 4.2" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"/></svg>
                </a>
            </div>
        </div>

        <div class="board-logo-grid reveal">
            <div class="board-logo-card"><img src="<?php echo e(asset($boards['aqa_image'])); ?>" alt="AQA exam board" loading="lazy" <?php if($isBoardsEditor): ?> data-edit-image="aqa_image" <?php endif; ?>></div>
            <div class="board-logo-card"><img src="<?php echo e(asset($boards['edexcel_image'])); ?>" alt="Pearson Edexcel exam board" loading="lazy" <?php if($isBoardsEditor): ?> data-edit-image="edexcel_image" <?php endif; ?>></div>
            <div class="board-logo-card"><img src="<?php echo e(asset($boards['ocr_image'])); ?>" alt="OCR exam board" loading="lazy" <?php if($isBoardsEditor): ?> data-edit-image="ocr_image" <?php endif; ?>></div>
            <div class="board-logo-card"><img src="<?php echo e(asset($boards['cambridge_image'])); ?>" alt="Cambridge International exam board" loading="lazy" <?php if($isBoardsEditor): ?> data-edit-image="cambridge_image" <?php endif; ?>></div>
            <div class="board-logo-card"><img src="<?php echo e(asset($boards['eduqas_image'])); ?>" alt="WJEC Eduqas exam board" loading="lazy" <?php if($isBoardsEditor): ?> data-edit-image="eduqas_image" <?php endif; ?>></div>
            <div class="board-logo-card"><img src="<?php echo e(asset($boards['pearson_image'])); ?>" alt="Pearson BTEC exam board" loading="lazy" <?php if($isBoardsEditor): ?> data-edit-image="pearson_image" <?php endif; ?>></div>
        </div>
    </div>
</section>
<?php /**PATH C:\xampp\htdocs\Graysexamcentre\resources\views\partials\exam-boards.blade.php ENDPATH**/ ?>