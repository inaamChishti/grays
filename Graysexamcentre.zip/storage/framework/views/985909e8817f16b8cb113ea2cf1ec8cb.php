<?php $__env->startSection('title', 'Page editor'); ?>
<?php $__env->startSection('kicker', 'Website'); ?>
<?php $__env->startSection('heading', 'Page editor'); ?>

<?php $__env->startSection('content'); ?>
<?php
    $editorUrl = $liveUrl.'?editor_preview=1&editor_section='.$slug;
    $extraFields = [];

    if (array_key_exists('title', $content) && ! str_starts_with($slug, 'blog-')) {
        $extraFields['title'] = [
            'label' => 'Browser and SEO title',
            'help' => 'The title shown in the browser tab and search results.',
            'type' => 'text',
        ];
    }

    if (array_key_exists('meta', $content)) {
        $extraFields['meta'] = [
            'label' => 'Meta description',
            'help' => 'A short description used by search engines and social previews.',
            'type' => 'textarea',
        ];
    }

    if ($slug === 'home') {
        $extraFields['hero_highlight'] = [
            'label' => 'Highlighted word in the main headline',
            'help' => 'This word is styled in gold inside the headline. Leave it blank to remove the highlight.',
            'type' => 'text',
        ];
    }

    if ($slug === 'contact') {
        $extraFields['map_query'] = [
            'label' => 'Google Maps search query',
            'help' => 'The address or place used by the embedded map on the contact page.',
            'type' => 'text',
        ];
    }
?>

<div class="page-title-row">
    <div>
        <h2>Edit <?php echo e($pageName); ?></h2>
        <p>Click directly on the page below to change text, or click an image to replace it.</p>
    </div>
    <div class="page-title-actions">
        <a href="<?php echo e(route('admin.pages.index')); ?>" class="btn-admin btn-admin--ghost">All pages</a>
        <a href="<?php echo e($liveUrl); ?>" target="_blank" rel="noopener" class="btn-admin btn-admin--ghost">View live page</a>
    </div>
</div>

<div class="page-picker">
    <label for="page-picker-select">Switch page</label>
    <select id="page-picker-select" onchange="if (this.value) { window.location.href = this.value; }">
        <?php $__currentLoopData = $groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $groupName => $pages): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <optgroup label="<?php echo e($groupName); ?>">
                <?php $__currentLoopData = $pages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pageSlug => $name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e(route('admin.pages.edit', $pageSlug)); ?>" <?php if($pageSlug === $slug): echo 'selected'; endif; ?>><?php echo e($name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </optgroup>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
</div>

<?php if($errors->any()): ?>
    <div class="admin-alert admin-alert--error" style="margin-bottom:1rem;">
        <svg viewBox="0 0 20 20" fill="none" aria-hidden="true"><circle cx="10" cy="10" r="7" stroke="currentColor" stroke-width="1.6"/><path d="M10 6v4.5M10 13.5h.01" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/></svg>
        <span><?php echo e($errors->first()); ?></span>
    </div>
<?php endif; ?>

<form id="page-editor-form" class="visual-editor" method="POST" action="<?php echo e(route('admin.pages.update', $slug)); ?>" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>

    <div class="visual-editor-toolbar">
        <div class="visual-editor-status">
            <span class="editor-status-dot" data-editor-dot></span>
            <div>
                <strong>Visual editor</strong>
                <span data-editor-status>Loading page preview&hellip;</span>
            </div>
        </div>
        <div class="visual-editor-actions">
            <button type="button" class="btn-admin btn-admin--ghost" data-editor-reload>Reload preview</button>
            <button type="submit" class="btn-admin btn-admin--primary" data-editor-save disabled>Save changes</button>
        </div>
    </div>

    <div class="visual-editor-hint">
        <span>Blue outlines are editable text. Click an image to choose a replacement. Links are disabled inside the preview.</span>
        <a href="<?php echo e($liveUrl); ?>" target="_blank" rel="noopener">Open live page &rarr;</a>
    </div>

    <div class="visual-editor-stage">
        <div class="visual-editor-loading" data-editor-loading>Loading page preview&hellip;</div>
        <iframe
            src="<?php echo e($editorUrl); ?>"
            title="<?php echo e($pageName); ?> visual preview"
            class="visual-editor-frame"
            data-editor-frame></iframe>
    </div>

    <?php if($extraFields): ?>
        <div class="form-panel visual-editor-extra">
            <p class="form-section-title">Page settings</p>
            <p class="visual-editor-extra-note">These settings are not shown as editable text on the preview.</p>

            <?php $__currentLoopData = $extraFields; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $field): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="admin-field">
                    <label for="field-<?php echo e($key); ?>"><?php echo e($field['label']); ?></label>
                    <?php if(($field['type'] ?? 'text') === 'textarea'): ?>
                        <textarea id="field-<?php echo e($key); ?>" name="page_fields[<?php echo e($key); ?>]" rows="3"><?php echo e(old('page_fields.'.$key, $content[$key] ?? '')); ?></textarea>
                    <?php else: ?>
                        <input id="field-<?php echo e($key); ?>" type="text" name="page_fields[<?php echo e($key); ?>]" value="<?php echo e(old('page_fields.'.$key, $content[$key] ?? '')); ?>">
                    <?php endif; ?>
                    <span class="visual-editor-extra-help"><?php echo e($field['help']); ?></span>
                    <?php $__errorArgs = ['page_fields.'.$key];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="field-error-admin"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    <?php endif; ?>

    <div class="visual-editor-foot">
        <p>Changes go live immediately after saving. Unsaved edits are lost if you leave this page.</p>
        <button type="submit" class="btn-admin btn-admin--primary" data-editor-save disabled>Save changes</button>
    </div>

    <div data-editor-fields></div>
</form>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script src="<?php echo e(asset('js/page-editor.js')); ?>?v=1.2" defer></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Graysexamcentre\resources\views/admin/pages/edit.blade.php ENDPATH**/ ?>