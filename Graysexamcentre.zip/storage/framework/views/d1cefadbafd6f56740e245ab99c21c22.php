<?php
    $isEdit = $course->exists;
    $levels = ['GCSE', 'IGCSE', 'A-Level', 'GCE O-Level', 'University', 'Adult', 'Other'];
?>

<form method="POST" action="<?php echo e($isEdit ? route('admin.courses.update', $course) : route('admin.courses.store')); ?>" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <?php if($isEdit): ?>
        <?php echo method_field('PUT'); ?>
    <?php endif; ?>

    <div class="form-panel">
        <div class="form-section">
            <p class="form-section-title">Course details</p>

            <div class="form-row">
                <div class="admin-field">
                    <label for="title">Course title <span>*</span></label>
                    <input id="title" type="text" name="title" value="<?php echo e(old('title', $course->title)); ?>" required maxlength="150" placeholder="e.g. GCSE Mathematics">
                    <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="field-error-admin"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="admin-field">
                    <label for="level">Level <span>*</span></label>
                    <select id="level" name="level" required>
                        <option value="">Choose a level</option>
                        <?php $__currentLoopData = $levels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $level): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($level); ?>" <?php echo e(old('level', $course->level) === $level ? 'selected' : ''); ?>><?php echo e($level); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php $__errorArgs = ['level'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="field-error-admin"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>

            <div class="admin-field">
                <label for="description">Description <span>*</span></label>
                <textarea id="description" name="description" rows="4" required maxlength="2000" placeholder="What does this course cover and who is it for?"><?php echo e(old('description', $course->description)); ?></textarea>
                <span class="hint">Keep it to roughly 2–3 sentences. This appears on the course card.</span>
                <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="field-error-admin"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>

        <div class="form-section">
            <p class="form-section-title">Delivery &amp; fees</p>

            <div class="form-row form-row--3">
                <div class="admin-field">
                    <label for="duration">Duration</label>
                    <input id="duration" type="text" name="duration" value="<?php echo e(old('duration', $course->duration)); ?>" maxlength="60" placeholder="e.g. 24 weeks">
                    <?php $__errorArgs = ['duration'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="field-error-admin"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="admin-field">
                    <label for="fee">Course fee</label>
                    <input id="fee" type="text" name="fee" value="<?php echo e(old('fee', $course->fee)); ?>" maxlength="60" placeholder="e.g. £720">
                    <?php $__errorArgs = ['fee'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="field-error-admin"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="admin-field">
                    <label for="sort_order">Display order</label>
                    <input id="sort_order" type="number" name="sort_order" value="<?php echo e(old('sort_order', $course->sort_order ?? 0)); ?>" min="0" max="999">
                    <span class="hint">Lower numbers appear first.</span>
                    <?php $__errorArgs = ['sort_order'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="field-error-admin"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>

            <div class="admin-field">
                <label for="schedule">Schedule</label>
                <input id="schedule" type="text" name="schedule" value="<?php echo e(old('schedule', $course->schedule)); ?>" maxlength="120" placeholder="e.g. Tuesdays, 5:00 – 7:00pm">
                <?php $__errorArgs = ['schedule'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="field-error-admin"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>

        <div class="form-section">
            <p class="form-section-title">Image</p>

            <div class="admin-field">
                <label for="image">Course image</label>
                <input id="image" type="file" name="image" accept="image/jpeg,image/png,image/webp" data-image-input>
                <span class="hint">JPG, PNG or WebP · up to 4 MB · recommended 1200 × 800px.</span>
                <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="field-error-admin"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                <?php if($course->image): ?>
                    <div class="image-preview" data-image-preview>
                        <img src="<?php echo e(asset($course->image)); ?>" alt="Current course image">
                        <span>Current image. Upload a new file to replace it.</span>
                    </div>
                <?php else: ?>
                    <div class="image-preview" data-image-preview>
                        <span>No image uploaded yet. A default study image will be used.</span>
                    </div>
                <?php endif; ?>
            </div>
        </div>

        <div class="form-section">
            <p class="form-section-title">Visibility</p>
            <label class="checkbox-row">
                <input type="checkbox" name="is_active" value="1" <?php echo e(old('is_active', $course->is_active ?? true) ? 'checked' : ''); ?>>
                Publish this course on the website
            </label>
        </div>

        <div class="form-actions">
            <a href="<?php echo e(route('admin.courses.index')); ?>" class="btn-admin btn-admin--ghost">Cancel</a>
            <button type="submit" class="btn-admin btn-admin--primary">
                <?php echo e($isEdit ? 'Save changes' : 'Create course'); ?>

            </button>
        </div>
    </div>
</form>
<?php /**PATH C:\xampp\htdocs\Graysexamcentre\resources\views\admin\courses\_form.blade.php ENDPATH**/ ?>