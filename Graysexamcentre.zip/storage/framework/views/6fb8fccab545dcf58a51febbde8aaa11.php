<?php
    $content = $content ?? \App\Support\SiteContent::get('form');
?>

<div class="form-embed-placeholder">
    <span class="form-embed-icon" aria-hidden="true">
        <svg viewBox="0 0 24 24" fill="none"><path d="M7 3.5h7l4 4V20a1.5 1.5 0 0 1-1.5 1.5h-9A1.5 1.5 0 0 1 6 20V5a1.5 1.5 0 0 1 1-1.5Z" stroke="currentColor" stroke-width="1.5" stroke-linejoin="round"/><path d="M14 3.5V8h4M9 12h6M9 15h6M9 18h4" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>
    </span>
    <h3 data-edit-key="form_placeholder_title"><?php echo e($content['form_placeholder_title']); ?></h3>
    <p data-edit-key="form_placeholder_text" data-edit-type="textarea"><?php echo e($content['form_placeholder_text']); ?></p>
    <a href="<?php echo e(route('contact.us')); ?>" class="btn btn--primary btn--sm"><span data-edit-key="form_placeholder_button"><?php echo e($content['form_placeholder_button']); ?></span></a>
</div>
<?php /**PATH C:\xampp\htdocs\Graysexamcentre\resources\views\partials\form-embed.blade.php ENDPATH**/ ?>