<article class="course-card reveal" data-level="<?php echo e(strtolower($course->level)); ?>">
    <div class="course-media">
        <img src="<?php echo e(asset($course->image ?: 'images/study-1.jpg')); ?>" alt="<?php echo e($course->title); ?> tuition at Grays Exam Centre" loading="lazy">
        <span class="level-badge"><?php echo e($course->level); ?></span>
    </div>
    <div class="course-body">
        <h3><?php echo e($course->title); ?></h3>
        <p><?php echo e($course->description); ?></p>

        <div class="course-meta">
            <?php if($course->duration): ?>
                <span>
                    <svg viewBox="0 0 20 20" fill="none" aria-hidden="true"><circle cx="10" cy="10" r="7" stroke="currentColor" stroke-width="1.5"/><path d="M10 6.5V10l2.4 1.5" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/></svg>
                    <?php echo e($course->duration); ?>

                </span>
            <?php endif; ?>
            <?php if($course->schedule): ?>
                <span>
                    <svg viewBox="0 0 20 20" fill="none" aria-hidden="true"><rect x="3.2" y="4.8" width="13.6" height="12" rx="2" stroke="currentColor" stroke-width="1.5"/><path d="M3.2 8.2h13.6M7 3.2v3M13 3.2v3" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/></svg>
                    <?php echo e($course->schedule); ?>

                </span>
            <?php endif; ?>
        </div>

        <div class="course-foot">
            <div class="course-price">
                <span>Course fee</span>
                <strong><?php echo e($course->fee ?: 'On request'); ?></strong>
            </div>
            <a href="<?php echo e(route('tuition.centre', ['course' => $course->title])); ?>#enquire"
               class="text-link"
               data-course-enquire
               data-course-title="<?php echo e($course->title); ?>">
                Enquire
                <svg viewBox="0 0 20 20" fill="none" aria-hidden="true"><path d="M4 10h11m0 0-4.2-4.2M15 10l-4.2 4.2" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"/></svg>
            </a>
        </div>
    </div>
</article>
<?php /**PATH C:\xampp\htdocs\Graysexamcentre\resources\views\partials\course-card.blade.php ENDPATH**/ ?>