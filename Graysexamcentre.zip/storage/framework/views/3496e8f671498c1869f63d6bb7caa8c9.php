<?php $__env->startSection('title', 'Message'); ?>
<?php $__env->startSection('kicker', 'Inbox'); ?>
<?php $__env->startSection('heading', 'Message'); ?>

<?php $__env->startSection('content'); ?>
<div class="page-title-row">
    <div>
        <h2><?php echo e($message->subject ?: 'General enquiry'); ?></h2>
        <p>Received <?php echo e($message->created_at->format('j F Y \a\t H:i')); ?> from <?php echo e($message->full_name); ?>.</p>
    </div>
    <a href="<?php echo e(route('admin.messages.index')); ?>" class="btn-admin btn-admin--ghost">&larr; Back to inbox</a>
</div>

<div class="message-layout">
    <article class="message-card">
        <div class="message-head">
            <div class="message-head-top">
                <span class="badge badge--<?php echo e($message->source); ?>"><?php echo e($message->source === 'tuition' ? 'Tuition enquiry' : 'Contact form'); ?></span>
                <span class="badge badge--<?php echo e($message->status); ?>"><?php echo e($message->status); ?></span>
            </div>
            <h2><?php echo e($message->subject ?: 'General enquiry'); ?></h2>
            <p>From <strong><?php echo e($message->full_name); ?></strong> &lt;<?php echo e($message->email); ?>&gt;</p>
        </div>
        <div class="message-body"><?php echo e($message->message); ?></div>
    </article>

    <aside style="display:grid;gap:1rem;">
        <section class="message-card">
            <div class="message-meta">
                <div class="meta-item">
                    <span>Full name</span>
                    <strong><?php echo e($message->full_name); ?></strong>
                </div>
                <div class="meta-item">
                    <span>Email</span>
                    <a href="mailto:<?php echo e($message->email); ?>"><?php echo e($message->email); ?></a>
                </div>
                <?php if($message->phone): ?>
                    <div class="meta-item">
                        <span>Phone</span>
                        <a href="tel:<?php echo e(preg_replace('/\s+/', '', $message->phone)); ?>"><?php echo e($message->phone); ?></a>
                    </div>
                <?php endif; ?>
                <div class="meta-item">
                    <span>Received</span>
                    <strong><?php echo e($message->created_at->format('j M Y, H:i')); ?></strong>
                </div>
                <div class="meta-item">
                    <span>Source</span>
                    <strong><?php echo e($message->source === 'tuition' ? 'Tuition Centre page' : 'Contact Us page'); ?></strong>
                </div>

                <div class="meta-divider"></div>

                <div class="meta-item">
                    <span>Update status</span>
                    <form method="POST" action="<?php echo e(route('admin.messages.status', $message)); ?>">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PATCH'); ?>
                        <div class="admin-field" style="margin:0.35rem 0 0;">
                            <select name="status" aria-label="Message status">
                                <option value="new" <?php echo e($message->status === 'new' ? 'selected' : ''); ?>>New</option>
                                <option value="read" <?php echo e($message->status === 'read' ? 'selected' : ''); ?>>Read</option>
                                <option value="archived" <?php echo e($message->status === 'archived' ? 'selected' : ''); ?>>Archived</option>
                            </select>
                        </div>
                        <button type="submit" class="btn-admin btn-admin--primary btn-admin--sm btn-admin--block" style="margin-top:0.5rem;">Save status</button>
                    </form>
                </div>

                <a href="mailto:<?php echo e($message->email); ?>?subject=<?php echo e(rawurlencode('Re: ' . ($message->subject ?: 'Your enquiry'))); ?>" class="btn-admin btn-admin--gold btn-admin--block">
                    Reply by email
                </a>

                <form method="POST" action="<?php echo e(route('admin.messages.destroy', $message)); ?>" data-confirm="Delete this message permanently?">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button type="submit" class="btn-admin btn-admin--danger btn-admin--sm btn-admin--block">Delete message</button>
                </form>
            </div>
        </section>
    </aside>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Graysexamcentre\resources\views\admin\messages\show.blade.php ENDPATH**/ ?>