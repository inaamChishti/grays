<?php
    $source = $source ?? 'contact';
    $subjectDefault = $subjectDefault ?? '';
?>

<form method="POST" action="<?php echo e(route('contact.store')); ?>" class="enquiry-form" data-enquiry-form>
    <?php echo csrf_field(); ?>
    <input type="hidden" name="source" value="<?php echo e($source); ?>">
    <div class="hp-field" aria-hidden="true">
        <label>Website<input type="text" name="website" tabindex="-1" autocomplete="off"></label>
    </div>

    <div class="form-grid">
        <div class="field">
            <label for="<?php echo e($source); ?>-name">Full name <span>*</span></label>
            <input id="<?php echo e($source); ?>-name" type="text" name="full_name" value="<?php echo e(old('full_name')); ?>" required autocomplete="name" placeholder="Your name">
            <?php $__errorArgs = ['full_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="field-error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="field">
            <label for="<?php echo e($source); ?>-email">Email address <span>*</span></label>
            <input id="<?php echo e($source); ?>-email" type="email" name="email" value="<?php echo e(old('email')); ?>" required autocomplete="email" placeholder="you@example.com">
            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="field-error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="field">
            <label for="<?php echo e($source); ?>-phone">Phone number</label>
            <input id="<?php echo e($source); ?>-phone" type="tel" name="phone" value="<?php echo e(old('phone')); ?>" autocomplete="tel" placeholder="Optional">
            <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="field-error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="field">
            <label for="<?php echo e($source); ?>-subject">Subject</label>
            <input id="<?php echo e($source); ?>-subject" type="text" name="subject" value="<?php echo e(old('subject', $subjectDefault)); ?>" placeholder="How can we help?" data-subject-input>
            <?php $__errorArgs = ['subject'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="field-error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="field field--full">
            <label for="<?php echo e($source); ?>-message">Message <span>*</span></label>
            <textarea id="<?php echo e($source); ?>-message" name="message" rows="5" required placeholder="Tell us a little about your goals, preferred dates or the course you are interested in."><?php echo e(old('message')); ?></textarea>
            <?php $__errorArgs = ['message'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="field-error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
    </div>

    <div class="form-foot">
        <p class="form-note">We reply within one working day. Your details are never shared.</p>
        <button type="submit" class="btn btn--primary" data-submit>
            Send message
            <svg viewBox="0 0 20 20" fill="none" aria-hidden="true"><path d="M4 10h11m0 0-4.2-4.2M15 10l-4.2 4.2" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"/></svg>
        </button>
    </div>

    <?php if($errors->any()): ?>
        <p class="form-general-error">Please check the highlighted fields and try again.</p>
    <?php endif; ?>
</form>
<?php /**PATH C:\xampp\htdocs\Graysexamcentre\resources\views\partials\enquiry-form.blade.php ENDPATH**/ ?>