<?php $__env->startSection('title', $content['title']); ?>
<?php $__env->startSection('meta_description', $content['meta']); ?>

<?php $__env->startSection('content'); ?>
<section class="page-hero content-hero">
    <div class="page-hero-glow" aria-hidden="true"></div>
    <div class="container page-hero-grid">
        <div class="page-hero-copy reveal">
            <nav class="breadcrumb" aria-label="Breadcrumb">
                <a href="<?php echo e(route('home')); ?>">Home</a>
                <span aria-hidden="true">/</span>
                <span>Tuition</span>
            </nav>
            <p class="eyebrow"><span class="eyebrow-dot"></span><span data-edit-key="hero_eyebrow"><?php echo e($content['hero_eyebrow']); ?></span></p>
            <h1 data-edit-key="hero_title"><?php echo e($content['hero_title']); ?></h1>
            <p class="lead" data-edit-key="hero_text" data-edit-type="textarea"><?php echo e($content['hero_text']); ?></p>

            <ul class="content-hero-points">
                <?php $__currentLoopData = $content['hero_points']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $point): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li>
                        <svg viewBox="0 0 20 20" fill="none" aria-hidden="true"><path d="m4.5 10.5 3.4 3.4 7.6-7.8" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"/></svg>
                        <span data-edit-key="hero_points.<?php echo e($index); ?>"><?php echo e($point); ?></span>
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>

            <div class="hero-actions">
                <a href="<?php echo e(route('contact.us')); ?>" class="btn btn--primary">
                    <span data-edit-key="hero_primary_label"><?php echo e($content['hero_primary_label']); ?></span>
                    <svg viewBox="0 0 20 20" fill="none" aria-hidden="true"><path d="M4 10h11m0 0-4.2-4.2M15 10l-4.2 4.2" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"/></svg>
                </a>
                <a href="<?php echo e(route('tuition.centre')); ?>" class="btn btn--ghost"><span data-edit-key="hero_secondary_label"><?php echo e($content['hero_secondary_label']); ?></span></a>
            </div>
        </div>

        <div class="page-hero-media reveal">
            <img src="<?php echo e(asset($content['hero_image'])); ?>" alt="A focused tuition session at Grays Exam Centre" data-edit-image="hero_image">
            <div class="page-hero-chip">
                <svg viewBox="0 0 20 20" fill="none" aria-hidden="true"><path d="M10 2.8 16 5.4v4.8c0 3.8-2.4 6.5-6 7.5-3.6-1-6-3.7-6-7.5V5.4L10 2.8Z" stroke="currentColor" stroke-width="1.5"/><path d="m7.4 9.8 1.8 1.8 3.5-3.6" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"/></svg>
                <span data-edit-key="hero_chip"><?php echo e($content['hero_chip']); ?></span>
            </div>
        </div>
    </div>
</section>

<section class="section section--paper">
    <div class="container split split--reverse">
        <div class="section-copy reveal">
            <p class="eyebrow"><span class="eyebrow-dot"></span><span data-edit-key="intro_eyebrow"><?php echo e($content['intro_eyebrow']); ?></span></p>
            <h2 data-edit-key="intro_title"><?php echo e($content['intro_title']); ?></h2>
            <p class="lead" data-edit-key="intro_text" data-edit-type="textarea"><?php echo e($content['intro_text']); ?></p>

            <ul class="feature-list">
                <?php $__currentLoopData = $content['benefits']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $benefit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li>
                        <span class="feature-icon"><svg viewBox="0 0 20 20" fill="none" aria-hidden="true"><path d="m4.5 10.5 3.4 3.4 7.6-7.8" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"/></svg></span>
                        <div><strong data-edit-key="benefits.<?php echo e($index); ?>.title"><?php echo e($benefit['title']); ?></strong><span data-edit-key="benefits.<?php echo e($index); ?>.text" data-edit-type="textarea"><?php echo e($benefit['text']); ?></span></div>
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>

            <a href="<?php echo e(route('contact.us')); ?>" class="btn btn--primary"><span data-edit-key="intro_cta_label"><?php echo e($content['intro_cta_label']); ?></span></a>
        </div>

        <div class="image-stack image-stack--tuition reveal">
            <div class="image-stack-main">
                <img src="<?php echo e(asset($content['intro_image_main'])); ?>" alt="Tutor supporting a student with exam preparation" loading="lazy" data-edit-image="intro_image_main">
            </div>
            <div class="image-stack-secondary">
                <img src="<?php echo e(asset($content['intro_image_secondary'])); ?>" alt="A bright tuition room in Grays" loading="lazy" data-edit-image="intro_image_secondary">
            </div>
            <div class="image-badge">
                <strong data-edit-key="intro_badge_value"><?php echo e($content['intro_badge_value']); ?></strong>
                <span data-edit-key="intro_badge_label"><?php echo e($content['intro_badge_label']); ?></span>
            </div>
        </div>
    </div>
</section>

<section class="section section--cream">
    <div class="container">
        <div class="section-head section-head--center reveal">
            <p class="eyebrow eyebrow--center"><span class="eyebrow-dot"></span><span data-edit-key="pathways_eyebrow"><?php echo e($content['pathways_eyebrow']); ?></span></p>
            <h2 data-edit-key="pathways_title"><?php echo e($content['pathways_title']); ?></h2>
            <p class="lead" data-edit-key="pathways_text" data-edit-type="textarea"><?php echo e($content['pathways_text']); ?></p>
        </div>

        <div class="info-card-grid">
            <?php $__currentLoopData = $content['pathways']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $pathway): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <article class="info-card info-card--content reveal">
                    <div>
                        <span class="info-tag" data-edit-key="pathways.<?php echo e($index); ?>.tag"><?php echo e($pathway['tag']); ?></span>
                        <h3 data-edit-key="pathways.<?php echo e($index); ?>.title"><?php echo e($pathway['title']); ?></h3>
                        <p data-edit-key="pathways.<?php echo e($index); ?>.text" data-edit-type="textarea"><?php echo e($pathway['text']); ?></p>
                        <a href="<?php echo e(route($pathway['route'])); ?>" class="text-link">
                            <span data-edit-key="pathways.<?php echo e($index); ?>.link"><?php echo e($pathway['link']); ?></span>
                            <svg viewBox="0 0 20 20" fill="none" aria-hidden="true"><path d="M4 10h11m0 0-4.2-4.2M15 10l-4.2 4.2" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"/></svg>
                        </a>
                    </div>
                </article>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</section>

<section class="section section--paper">
    <div class="container">
        <div class="section-head section-head--center reveal">
            <p class="eyebrow eyebrow--center"><span class="eyebrow-dot"></span><span data-edit-key="approach_eyebrow"><?php echo e($content['approach_eyebrow']); ?></span></p>
            <h2 data-edit-key="approach_title"><?php echo e($content['approach_title']); ?></h2>
        </div>

        <div class="feature-grid">
            <?php $__currentLoopData = $content['approach_items']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <article class="feature-card reveal">
                    <span class="feature-card-num"><?php echo e(str_pad($index + 1, 2, '0', STR_PAD_LEFT)); ?></span>
                    <h3 data-edit-key="approach_items.<?php echo e($index); ?>.title"><?php echo e($item['title']); ?></h3>
                    <p data-edit-key="approach_items.<?php echo e($index); ?>.text" data-edit-type="textarea"><?php echo e($item['text']); ?></p>
                </article>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</section>

<section class="section section--cream">
    <div class="container">
        <div class="section-head section-head--center reveal">
            <p class="eyebrow eyebrow--center"><span class="eyebrow-dot"></span><span data-edit-key="steps_eyebrow"><?php echo e($content['steps_eyebrow']); ?></span></p>
            <h2 data-edit-key="steps_title"><?php echo e($content['steps_title']); ?></h2>
        </div>

        <div class="steps">
            <?php $__currentLoopData = $content['steps_items']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <article class="step reveal">
                    <span class="step-num"><?php echo e(str_pad($index + 1, 2, '0', STR_PAD_LEFT)); ?></span>
                    <h3 data-edit-key="steps_items.<?php echo e($index); ?>.title"><?php echo e($item['title']); ?></h3>
                    <p data-edit-key="steps_items.<?php echo e($index); ?>.text" data-edit-type="textarea"><?php echo e($item['text']); ?></p>
                </article>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</section>

<section class="section section--paper">
    <div class="container content-narrow">
        <div class="section-head reveal">
            <p class="eyebrow"><span class="eyebrow-dot"></span><span data-edit-key="faq_eyebrow"><?php echo e($content['faq_eyebrow']); ?></span></p>
            <h2 data-edit-key="faq_title"><?php echo e($content['faq_title']); ?></h2>
        </div>

        <div class="faq-list reveal">
            <?php $__currentLoopData = $content['faq_items']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <details <?php echo e($loop->first ? 'open' : ''); ?>>
                    <summary data-edit-key="faq_items.<?php echo e($index); ?>.q"><?php echo e($item['q']); ?></summary>
                    <p data-edit-key="faq_items.<?php echo e($index); ?>.a" data-edit-type="textarea"><?php echo e($item['a']); ?></p>
                </details>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</section>

<section class="cta-section">
    <div class="container">
        <div class="cta-band reveal">
            <div class="cta-orbs" aria-hidden="true"></div>
            <div class="cta-copy">
                <p class="eyebrow eyebrow--light"><span class="eyebrow-dot"></span><span data-edit-key="cta_eyebrow"><?php echo e($content['cta_eyebrow']); ?></span></p>
                <h2 data-edit-key="cta_title"><?php echo e($content['cta_title']); ?></h2>
                <p data-edit-key="cta_text" data-edit-type="textarea"><?php echo e($content['cta_text']); ?></p>
            </div>
            <div class="cta-actions">
                <a href="<?php echo e(route('contact.us')); ?>" class="btn btn--gold"><span data-edit-key="cta_primary_label"><?php echo e($content['cta_primary_label']); ?></span></a>
                <a href="<?php echo e(route('tuition.centre')); ?>" class="btn btn--outline-light"><span data-edit-key="cta_secondary_label"><?php echo e($content['cta_secondary_label']); ?></span></a>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Graysexamcentre\resources\views\tuition-page.blade.php ENDPATH**/ ?>