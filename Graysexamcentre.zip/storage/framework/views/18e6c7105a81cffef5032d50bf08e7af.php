<?php
    $type = $block['type'] ?? 'prose';
    $tone = $tone ?? 'paper';
    $prefix = $prefix ?? 'blocks.0';
    $key = fn ($path) => $prefix.'.'.$path;
?>

<?php if($type === 'cards'): ?>
    <section class="section section--<?php echo e($tone); ?>">
        <div class="container">
            <div class="section-head section-head--center reveal">
                <?php if(! empty($block['eyebrow'])): ?>
                    <p class="eyebrow eyebrow--center"><span class="eyebrow-dot"></span><span data-edit-key="<?php echo e($key('eyebrow')); ?>"><?php echo e($block['eyebrow']); ?></span></p>
                <?php endif; ?>
                <h2 data-edit-key="<?php echo e($key('title')); ?>"><?php echo e($block['title'] ?? ''); ?></h2>
                <?php if(! empty($block['text'])): ?>
                    <p class="lead" data-edit-key="<?php echo e($key('text')); ?>" data-edit-type="textarea"><?php echo e($block['text']); ?></p>
                <?php endif; ?>
            </div>

            <div class="info-card-grid">
                <?php $__currentLoopData = $block['items'] ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <article class="info-card info-card--content reveal">
                        <div>
                            <?php if(! empty($item['tag'])): ?>
                                <span class="info-tag" data-edit-key="<?php echo e($key('items.'.$index.'.tag')); ?>"><?php echo e($item['tag']); ?></span>
                            <?php endif; ?>
                            <h3 data-edit-key="<?php echo e($key('items.'.$index.'.title')); ?>"><?php echo e($item['title']); ?></h3>
                            <p data-edit-key="<?php echo e($key('items.'.$index.'.text')); ?>" data-edit-type="textarea"><?php echo e($item['text']); ?></p>
                            <?php if(! empty($item['route']) && \Illuminate\Support\Facades\Route::has($item['route'])): ?>
                                <a href="<?php echo e(route($item['route'])); ?>" class="text-link">
                                    <span data-edit-key="<?php echo e($key('items.'.$index.'.link')); ?>"><?php echo e($item['link'] ?? 'Read more'); ?></span>
                                    <svg viewBox="0 0 20 20" fill="none" aria-hidden="true"><path d="M4 10h11m0 0-4.2-4.2M15 10l-4.2 4.2" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"/></svg>
                                </a>
                            <?php endif; ?>
                        </div>
                    </article>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </section>

<?php elseif($type === 'features'): ?>
    <section class="section section--<?php echo e($tone); ?>">
        <div class="container">
            <div class="section-head section-head--center reveal">
                <?php if(! empty($block['eyebrow'])): ?>
                    <p class="eyebrow eyebrow--center"><span class="eyebrow-dot"></span><span data-edit-key="<?php echo e($key('eyebrow')); ?>"><?php echo e($block['eyebrow']); ?></span></p>
                <?php endif; ?>
                <h2 data-edit-key="<?php echo e($key('title')); ?>"><?php echo e($block['title'] ?? ''); ?></h2>
                <?php if(! empty($block['text'])): ?>
                    <p class="lead" data-edit-key="<?php echo e($key('text')); ?>" data-edit-type="textarea"><?php echo e($block['text']); ?></p>
                <?php endif; ?>
            </div>

            <div class="feature-grid">
                <?php $__currentLoopData = $block['items'] ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <article class="feature-card reveal">
                        <span class="feature-card-num"><?php echo e(str_pad($index + 1, 2, '0', STR_PAD_LEFT)); ?></span>
                        <h3 data-edit-key="<?php echo e($key('items.'.$index.'.title')); ?>"><?php echo e($item['title']); ?></h3>
                        <p data-edit-key="<?php echo e($key('items.'.$index.'.text')); ?>" data-edit-type="textarea"><?php echo e($item['text']); ?></p>
                    </article>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </section>

<?php elseif($type === 'table'): ?>
    <section class="section section--<?php echo e($tone); ?>">
        <div class="container content-wide">
            <div class="section-head reveal">
                <?php if(! empty($block['eyebrow'])): ?>
                    <p class="eyebrow"><span class="eyebrow-dot"></span><span data-edit-key="<?php echo e($key('eyebrow')); ?>"><?php echo e($block['eyebrow']); ?></span></p>
                <?php endif; ?>
                <h2 data-edit-key="<?php echo e($key('title')); ?>"><?php echo e($block['title'] ?? ''); ?></h2>
                <?php if(! empty($block['text'])): ?>
                    <p class="lead" data-edit-key="<?php echo e($key('text')); ?>" data-edit-type="textarea"><?php echo e($block['text']); ?></p>
                <?php endif; ?>
            </div>

            <div class="table-wrap reveal">
                <table class="content-table">
                    <thead>
                        <tr>
                            <?php $__currentLoopData = $block['columns'] ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $column): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <th scope="col" data-edit-key="<?php echo e($key('columns.'.$index)); ?>"><?php echo e($column); ?></th>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $block['rows'] ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rowIndex => $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <?php $__currentLoopData = $row; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cellIndex => $cell): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <td data-edit-key="<?php echo e($key('rows.'.$rowIndex.'.'.$cellIndex)); ?>"><?php echo e($cell); ?></td>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>

            <?php if(! empty($block['note'])): ?>
                <p class="table-note" data-edit-key="<?php echo e($key('note')); ?>" data-edit-type="textarea"><?php echo e($block['note']); ?></p>
            <?php endif; ?>
        </div>
    </section>

<?php elseif($type === 'faq'): ?>
    <section class="section section--<?php echo e($tone); ?>">
        <div class="container content-narrow">
            <div class="section-head reveal">
                <?php if(! empty($block['eyebrow'])): ?>
                    <p class="eyebrow"><span class="eyebrow-dot"></span><span data-edit-key="<?php echo e($key('eyebrow')); ?>"><?php echo e($block['eyebrow']); ?></span></p>
                <?php endif; ?>
                <h2 data-edit-key="<?php echo e($key('title')); ?>"><?php echo e($block['title'] ?? 'Questions, answered'); ?></h2>
            </div>

            <div class="faq-list reveal">
                <?php $__currentLoopData = $block['items'] ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <details>
                        <summary data-edit-key="<?php echo e($key('items.'.$index.'.q')); ?>"><?php echo e($item['q']); ?></summary>
                        <p data-edit-key="<?php echo e($key('items.'.$index.'.a')); ?>" data-edit-type="textarea"><?php echo e($item['a']); ?></p>
                    </details>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </section>

<?php elseif($type === 'steps'): ?>
    <section class="section section--<?php echo e($tone); ?>">
        <div class="container">
            <div class="section-head section-head--center reveal">
                <?php if(! empty($block['eyebrow'])): ?>
                    <p class="eyebrow eyebrow--center"><span class="eyebrow-dot"></span><span data-edit-key="<?php echo e($key('eyebrow')); ?>"><?php echo e($block['eyebrow']); ?></span></p>
                <?php endif; ?>
                <h2 data-edit-key="<?php echo e($key('title')); ?>"><?php echo e($block['title'] ?? ''); ?></h2>
                <?php if(! empty($block['text'])): ?>
                    <p class="lead" data-edit-key="<?php echo e($key('text')); ?>" data-edit-type="textarea"><?php echo e($block['text']); ?></p>
                <?php endif; ?>
            </div>

            <div class="steps steps--content">
                <?php $__currentLoopData = $block['items'] ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <article class="step reveal">
                        <span class="step-num"><?php echo e(str_pad($index + 1, 2, '0', STR_PAD_LEFT)); ?></span>
                        <h3 data-edit-key="<?php echo e($key('items.'.$index.'.title')); ?>"><?php echo e($item['title']); ?></h3>
                        <p data-edit-key="<?php echo e($key('items.'.$index.'.text')); ?>" data-edit-type="textarea"><?php echo e($item['text']); ?></p>
                    </article>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </section>

<?php else: ?>
    <section class="section section--<?php echo e($tone); ?>">
        <div class="container content-narrow">
            <div class="content-prose reveal">
                <?php if(! empty($block['eyebrow'])): ?>
                    <p class="eyebrow"><span class="eyebrow-dot"></span><span data-edit-key="<?php echo e($key('eyebrow')); ?>"><?php echo e($block['eyebrow']); ?></span></p>
                <?php endif; ?>
                <?php if(! empty($block['title'])): ?>
                    <h2 data-edit-key="<?php echo e($key('title')); ?>"><?php echo e($block['title']); ?></h2>
                <?php endif; ?>
                <?php if(! empty($block['text'])): ?>
                    <p class="lead" data-edit-key="<?php echo e($key('text')); ?>" data-edit-type="textarea"><?php echo e($block['text']); ?></p>
                <?php endif; ?>
                <?php $__currentLoopData = $block['paragraphs'] ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $paragraph): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <p data-edit-key="<?php echo e($key('paragraphs.'.$index)); ?>" data-edit-type="textarea"><?php echo e($paragraph); ?></p>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php if(! empty($block['bullets'])): ?>
                    <ul class="check-list">
                        <?php $__currentLoopData = $block['bullets']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $bullet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li data-edit-key="<?php echo e($key('bullets.'.$index)); ?>" data-edit-type="textarea"><?php echo e($bullet); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                <?php endif; ?>
            </div>
        </div>
    </section>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\Graysexamcentre\resources\views\partials\content-block.blade.php ENDPATH**/ ?>