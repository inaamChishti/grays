<?php $__env->startSection('title', $content['title']); ?>
<?php $__env->startSection('meta_description', $content['meta']); ?>

<?php $__env->startSection('content'); ?>
<section class="page-hero form-hero">
    <div class="page-hero-glow" aria-hidden="true"></div>
    <div class="container page-hero-grid">
        <div class="page-hero-copy reveal">
            <nav class="breadcrumb" aria-label="Breadcrumb">
                <a href="<?php echo e(route('home')); ?>">Home</a>
                <span aria-hidden="true">/</span>
                <span>Online Form</span>
            </nav>
            <p class="eyebrow"><span class="eyebrow-dot"></span><span data-edit-key="hero_eyebrow"><?php echo e($content['hero_eyebrow']); ?></span></p>
            <h1 data-edit-key="hero_title"><?php echo e($content['hero_title']); ?></h1>
            <p class="lead" data-edit-key="hero_text" data-edit-type="textarea"><?php echo e($content['hero_text']); ?></p>

            <ul class="content-hero-points">
                <?php $__currentLoopData = $content['hero_points']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $point): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li>
                        <svg viewBox="0 0 20 20" fill="none" aria-hidden="true"><path d="m4.5 10.5 3.4 3.4 7.6-7.8" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"/></svg>
                        <span data-edit-key="hero_points.<?php echo e($index); ?>"><?php echo e($point); ?></span>
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>

        <aside class="form-hero-card reveal">
            <p class="eyebrow"><span class="eyebrow-dot"></span><span data-edit-key="card_eyebrow"><?php echo e($content['card_eyebrow']); ?></span></p>
            <h2 data-edit-key="card_title"><?php echo e($content['card_title']); ?></h2>
            <ul>
                <?php $__currentLoopData = $content['card_items']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li data-edit-key="card_items.<?php echo e($index); ?>" data-edit-type="textarea"><?php echo e($item); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
            <a href="<?php echo e(route('contact.us')); ?>" class="text-link"><span data-edit-key="card_link_label"><?php echo e($content['card_link_label']); ?></span>
                <svg viewBox="0 0 20 20" fill="none" aria-hidden="true"><path d="M4 10h11m0 0-4.2-4.2M15 10l-4.2 4.2" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"/></svg>
            </a>
        </aside>
    </div>
</section>

<section class="section section--paper">
    <div class="container content-narrow">
        <div class="section-head section-head--center reveal">
            <p class="eyebrow eyebrow--center"><span class="eyebrow-dot"></span><span data-edit-key="form_eyebrow"><?php echo e($content['form_eyebrow']); ?></span></p>
            <h2 data-edit-key="form_title"><?php echo e($content['form_title']); ?></h2>
            <p class="lead" data-edit-key="form_text" data-edit-type="textarea"><?php echo e($content['form_text']); ?></p>
        </div>

        <div class="form-embed-shell reveal" id="online-form">
            <div class="form-embed-head">
                <div>
                    <span class="form-embed-label" data-edit-key="form_label"><?php echo e($content['form_label']); ?></span>
                    <strong data-edit-key="form_brand"><?php echo e($content['form_brand']); ?></strong>
                </div>
                <span class="form-embed-status">
                    <span aria-hidden="true"></span>
                    <span data-edit-key="form_status"><?php echo e($content['form_status']); ?></span>
                </span>
            </div>
            <div class="form-embed-body">
                <?php echo $__env->make('partials.form-embed', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        </div>

        <p class="form-embed-note reveal"><span data-edit-key="form_note"><?php echo e($content['form_note']); ?></span> Read our <a href="<?php echo e(route('privacy.policy')); ?>">privacy policy</a>.</p>
    </div>
</section>

<section class="section section--cream">
    <div class="container">
        <div class="cta-band reveal">
            <div class="cta-orbs" aria-hidden="true"></div>
            <div class="cta-copy">
                <p class="eyebrow eyebrow--light"><span class="eyebrow-dot"></span><span data-edit-key="cta_eyebrow"><?php echo e($content['cta_eyebrow']); ?></span></p>
                <h2 data-edit-key="cta_title"><?php echo e($content['cta_title']); ?></h2>
                <p data-edit-key="cta_text" data-edit-type="textarea"><?php echo e($content['cta_text']); ?></p>
            </div>
            <div class="cta-actions">
                <a href="<?php echo e(route('contact.us')); ?>" class="btn btn--gold"><span data-edit-key="cta_primary_label"><?php echo e($content['cta_primary_label']); ?></span></a>
                <a href="tel:<?php echo e(preg_replace('/\s+/', '', \App\Support\SiteContent::get('contact')['phone'])); ?>" class="btn btn--outline-light"><span data-edit-key="cta_secondary_label"><?php echo e($content['cta_secondary_label']); ?></span></a>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Graysexamcentre\resources\views\form.blade.php ENDPATH**/ ?>