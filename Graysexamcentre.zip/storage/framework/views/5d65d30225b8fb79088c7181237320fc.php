<?php $__env->startSection('title', 'Add course'); ?>
<?php $__env->startSection('kicker', 'Tuition'); ?>
<?php $__env->startSection('heading', 'Add course'); ?>

<?php $__env->startSection('content'); ?>
<div class="page-title-row">
    <div>
        <h2>New tuition course</h2>
        <p>Add a course to the public Tuition Centre page.</p>
    </div>
    <a href="<?php echo e(route('admin.courses.index')); ?>" class="btn-admin btn-admin--ghost">&larr; Back to courses</a>
</div>

<?php echo $__env->make('admin.courses._form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Graysexamcentre\resources\views\admin\courses\create.blade.php ENDPATH**/ ?>