<?php $__env->startSection('title', $content['title'].' | Grays Exam Centre'); ?>
<?php $__env->startSection('meta_description', $content['excerpt']); ?>

<?php $__env->startSection('content'); ?>
<?php
    $tones = ['paper', 'cream'];
    $blockIndex = 0;
?>

<section class="page-hero blog-post-hero">
    <div class="page-hero-glow" aria-hidden="true"></div>
    <div class="container page-hero-grid">
        <div class="page-hero-copy reveal">
            <nav class="breadcrumb" aria-label="Breadcrumb">
                <a href="<?php echo e(route('home')); ?>">Home</a>
                <span aria-hidden="true">/</span>
                <a href="<?php echo e(route('blog')); ?>">Blog</a>
                <span aria-hidden="true">/</span>
                <span><?php echo e($post['category']); ?></span>
            </nav>
            <div class="blog-meta blog-meta--hero">
                <span class="blog-tag" data-edit-key="category"><?php echo e($post['category']); ?></span>
                <span data-edit-key="date"><?php echo e(\Illuminate\Support\Carbon::parse($post['date'])->format('j F Y')); ?></span>
                <span data-edit-key="read_time"><?php echo e($post['read_time']); ?></span>
            </div>
            <h1 data-edit-key="title"><?php echo e($post['title']); ?></h1>
            <p class="lead" data-edit-key="excerpt" data-edit-type="textarea"><?php echo e($post['excerpt']); ?></p>
        </div>
        <div class="page-hero-media reveal">
            <img src="<?php echo e(asset($post['image'])); ?>" alt="<?php echo e($post['title']); ?>" data-edit-image="image">
            <div class="page-hero-chip">
                <svg viewBox="0 0 20 20" fill="none" aria-hidden="true"><path d="M10 2.8 16 5.4v4.8c0 3.8-2.4 6.5-6 7.5-3.6-1-6-3.7-6-7.5V5.4L10 2.8Z" stroke="currentColor" stroke-width="1.5"/><path d="m7.4 9.8 1.8 1.8 3.5-3.6" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"/></svg>
                Grays Exam Centre
            </div>
        </div>
    </div>
</section>

<?php $__currentLoopData = $post['body']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $block): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php echo $__env->make('partials.content-block', [
        'block' => $block,
        'tone' => $tones[$blockIndex % 2],
        'prefix' => 'body.'.$blockIndex,
    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php $blockIndex++; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<section class="cta-section">
    <div class="container">
        <div class="cta-band reveal">
            <div class="cta-orbs" aria-hidden="true"></div>
            <div class="cta-copy">
                <p class="eyebrow eyebrow--light"><span class="eyebrow-dot"></span><span data-edit-key="cta_eyebrow"><?php echo e($content['cta_eyebrow']); ?></span></p>
                <h2 data-edit-key="cta_title"><?php echo e($content['cta_title']); ?></h2>
                <p data-edit-key="cta_text" data-edit-type="textarea"><?php echo e($content['cta_text']); ?></p>
            </div>
            <div class="cta-actions">
                <a href="<?php echo e(route('contact.us')); ?>" class="btn btn--gold">Ask the exams team</a>
            </div>
        </div>
    </div>
</section>

<?php if(! empty($related)): ?>
    <section class="section section--cream">
        <div class="container">
            <div class="section-head section-head--split reveal">
                <div>
                    <p class="eyebrow"><span class="eyebrow-dot"></span>Keep reading</p>
                    <h2>More practical guidance.</h2>
                </div>
                <div>
                    <a href="<?php echo e(route('blog')); ?>" class="text-link">View all articles
                        <svg viewBox="0 0 20 20" fill="none" aria-hidden="true"><path d="M4 10h11m0 0-4.2-4.2M15 10l-4.2 4.2" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"/></svg>
                    </a>
                </div>
            </div>

            <div class="blog-grid blog-grid--related">
                <?php $__currentLoopData = $related; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <article class="blog-card reveal">
                        <a href="<?php echo e(route('blog.post', $item['slug'])); ?>" class="blog-card-image" aria-hidden="true" tabindex="-1">
                            <img src="<?php echo e(asset($item['image'])); ?>" alt="" loading="lazy">
                        </a>
                        <div class="blog-card-body">
                            <div class="blog-meta">
                                <span class="blog-tag"><?php echo e($item['category']); ?></span>
                                <span><?php echo e(\Illuminate\Support\Carbon::parse($item['date'])->format('j M Y')); ?></span>
                            </div>
                            <h2><a href="<?php echo e(route('blog.post', $item['slug'])); ?>"><?php echo e($item['title']); ?></a></h2>
                            <p><?php echo e($item['excerpt']); ?></p>
                        </div>
                    </article>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </section>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Graysexamcentre\resources\views\blog\show.blade.php ENDPATH**/ ?>