<?php $__env->startSection('title', 'Dashboard'); ?>
<?php $__env->startSection('kicker', 'Overview'); ?>
<?php $__env->startSection('heading', 'Welcome back, ' . strtok(auth()->user()->name, ' ')); ?>

<?php $__env->startSection('content'); ?>
<div class="stats-grid">
    <article class="stat-card">
        <div class="stat-card-head">
            <span>Unread messages</span>
            <span class="stat-card-icon">
                <svg viewBox="0 0 24 24" fill="none" aria-hidden="true"><rect x="3.5" y="5" width="17" height="14" rx="2.2" stroke="currentColor" stroke-width="1.6"/><path d="m4.5 6.6 7.5 5.4 7.5-5.4" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/></svg>
            </span>
        </div>
        <strong><?php echo e($unreadMessages); ?></strong>
        <small>Awaiting a reply</small>
    </article>

    <article class="stat-card">
        <div class="stat-card-head">
            <span>Total messages</span>
            <span class="stat-card-icon">
                <svg viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="M4.5 5.5h15v11h-8.2L7 20v-3.5H4.5v-11Z" stroke="currentColor" stroke-width="1.6" stroke-linejoin="round"/><path d="M8.2 9.2h7.6M8.2 12.4h5.2" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/></svg>
            </span>
        </div>
        <strong><?php echo e($totalMessages); ?></strong>
        <small>All contact and tuition enquiries</small>
    </article>

    <article class="stat-card">
        <div class="stat-card-head">
            <span>Live courses</span>
            <span class="stat-card-icon">
                <svg viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="M4.5 6.2c2.7-.8 5-.2 7.5 1.3v11.2c-2.5-1.5-4.8-2.1-7.5-1.3V6.2Z" stroke="currentColor" stroke-width="1.6" stroke-linejoin="round"/><path d="M19.5 6.2c-2.7-.8-5-.2-7.5 1.3v11.2c2.5-1.5 4.8-2.1 7.5-1.3V6.2Z" stroke="currentColor" stroke-width="1.6" stroke-linejoin="round"/></svg>
            </span>
        </div>
        <strong><?php echo e($activeCourses); ?></strong>
        <small>Published to the website</small>
    </article>

    <article class="stat-card">
        <div class="stat-card-head">
            <span>All courses</span>
            <span class="stat-card-icon">
                <svg viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="m12 4 8 3.4-8 3.4-8-3.4L12 4Z" stroke="currentColor" stroke-width="1.6" stroke-linejoin="round"/><path d="m4 11 8 3.4 8-3.4M4 14.8l8 3.4 8-3.4" stroke="currentColor" stroke-width="1.6" stroke-linejoin="round"/></svg>
            </span>
        </div>
        <strong><?php echo e($totalCourses); ?></strong>
        <small>Including unpublished</small>
    </article>
</div>

<div class="panel-grid">
    <section class="panel">
        <div class="panel-head">
            <h2>Recent enquiries</h2>
            <a href="<?php echo e(route('admin.messages.index')); ?>" class="text-link-admin">View all</a>
        </div>

        <?php if($recentMessages->isEmpty()): ?>
            <div class="empty-row">
                <strong>No enquiries yet</strong>
                Messages sent from the website will appear here.
            </div>
        <?php else: ?>
            <div class="table-wrap">
                <table class="data-table">
                    <thead>
                        <tr>
                            <th>From</th>
                            <th>Subject</th>
                            <th>Received</th>
                            <th></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $recentMessages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>
                                    <div class="cell-title">
                                        <span>
                                            <strong><?php echo e($message->full_name); ?></strong>
                                            <span><?php echo e($message->email); ?></span>
                                        </span>
                                    </div>
                                </td>
                                <td>
                                    <div style="display:flex;flex-direction:column;gap:4px;">
                                        <span><?php echo e($message->subject ?: 'General enquiry'); ?></span>
                                        <span class="badge badge--<?php echo e($message->source); ?>"><?php echo e($message->source); ?></span>
                                    </div>
                                </td>
                                <td><?php echo e($message->created_at->format('j M, H:i')); ?></td>
                                <td style="text-align:right;">
                                    <a href="<?php echo e(route('admin.messages.show', $message)); ?>" class="btn-admin btn-admin--ghost btn-admin--sm">Open</a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </section>

    <div style="display:grid;gap:1.2rem;align-content:start;">
        <section class="panel">
            <div class="panel-head">
                <h2>Quick actions</h2>
            </div>
            <div class="panel-body">
                <div class="quick-grid">
                    <a href="<?php echo e(route('admin.courses.create')); ?>" class="quick-card">
                        <span class="quick-icon">
                            <svg viewBox="0 0 20 20" fill="none" aria-hidden="true"><path d="M10 4v12M4 10h12" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/></svg>
                        </span>
                        <span>
                            <strong>Add a course</strong>
                            <span>Publish new tuition</span>
                        </span>
                    </a>
                    <a href="<?php echo e(route('admin.messages.index', ['status' => 'new'])); ?>" class="quick-card">
                        <span class="quick-icon">
                            <svg viewBox="0 0 20 20" fill="none" aria-hidden="true"><rect x="3" y="4.5" width="14" height="11" rx="2" stroke="currentColor" stroke-width="1.5"/><path d="m4 6 6 4.4L16 6" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/></svg>
                        </span>
                        <span>
                            <strong>Unread inbox</strong>
                            <span><?php echo e($unreadMessages); ?> awaiting reply</span>
                        </span>
                    </a>
                    <a href="<?php echo e(route('admin.pages.index')); ?>" class="quick-card">
                        <span class="quick-icon">
                            <svg viewBox="0 0 20 20" fill="none" aria-hidden="true"><rect x="3" y="3" width="14" height="14" rx="2" stroke="currentColor" stroke-width="1.5"/><path d="M6.5 7h7M6.5 10h7M6.5 13h4" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/></svg>
                        </span>
                        <span>
                            <strong>Edit website pages</strong>
                            <span>Text, images and settings</span>
                        </span>
                    </a>
                    <a href="<?php echo e(route('admin.pages.edit', 'exam-boards-section')); ?>" class="quick-card">
                        <span class="quick-icon">
                            <svg viewBox="0 0 20 20" fill="none" aria-hidden="true"><circle cx="10" cy="10" r="6.5" stroke="currentColor" stroke-width="1.5"/><path d="M3.5 10h13M10 3.5c1.8 1.8 2.8 4 2.8 6.5S11.8 14.7 10 16.5C8.2 14.7 7.2 12.5 7.2 10S8.2 5.3 10 3.5Z" stroke="currentColor" stroke-width="1.5"/></svg>
                        </span>
                        <span>
                            <strong>Edit exam boards</strong>
                            <span>Shared text and logos</span>
                        </span>
                    </a>
                    <a href="<?php echo e(route('home')); ?>" target="_blank" rel="noopener" class="quick-card">
                        <span class="quick-icon">
                            <svg viewBox="0 0 20 20" fill="none" aria-hidden="true"><path d="M12 3.5h4.5V8M16 4l-6 6" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/><path d="M15.5 11v3.5a1.5 1.5 0 0 1-1.5 1.5H5.5A1.5 1.5 0 0 1 4 14.5V6a1.5 1.5 0 0 1 1.5-1.5H9" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/></svg>
                        </span>
                        <span>
                            <strong>View website</strong>
                            <span>Open the public site</span>
                        </span>
                    </a>
                </div>
            </div>
        </section>

        <section class="panel">
            <div class="panel-head">
                <h2>Recently updated courses</h2>
                <a href="<?php echo e(route('admin.courses.index')); ?>" class="text-link-admin">Manage</a>
            </div>
            <div class="panel-body" style="display:grid;gap:0.8rem;">
                <?php $__empty_1 = true; $__currentLoopData = $recentCourses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <a href="<?php echo e(route('admin.courses.edit', $course)); ?>" class="quick-card" style="align-items:center;">
                        <img class="cell-thumb" src="<?php echo e(asset($course->image ?: 'images/study-1.jpg')); ?>" alt="">
                        <span style="flex:1;">
                            <strong><?php echo e($course->title); ?></strong>
                            <span><?php echo e($course->level); ?> · <?php echo e($course->updated_at->diffForHumans()); ?></span>
                        </span>
                    </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <p style="font-size:0.8rem;color:var(--muted);">No courses have been added yet.</p>
                <?php endif; ?>
            </div>
        </section>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Graysexamcentre\resources\views\admin\dashboard.blade.php ENDPATH**/ ?>